/*
NOAH BOUSHEE
USE MAKEFILE
Homework 10 program 0 Noah Boushee
Write a main program that spawns 9 children through forking and execing
Pass these children a pipe, a semaphore identifier, and the commandline file name
each child reads between 1 and 10 characters and sends those back to parent
The semaphore synchonizes them

wc -c input.txt GETS NUMBER OF CHARACTERS

*/

#include <semaphore.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <fcntl.h>

#define numChildren 9

enum {SEGMENT_SIZE = 0x6400};

int main(int argc, char *argv[]){
    if (argc != 2){
        printf("NOT ENOUGH COMMANDLINE ARGUMENTS\n");
        printf("USAGE: ./programName <FILE NAME>");
        exit(-1);
    }

    pid_t forkId, waitId;
    sem_t *semaphore0;
    int oflag = O_CREAT, p[numChildren][2], semId, status = 0;
    int * numCharsInitial = 0;
	unsigned int value = 0;
    mode_t mode = 0644;
    char semname[] = "homeworkFinalSemaphoreOne";
    char input[100];
    semaphore0 = sem_open(semname, oflag, mode, 1);
    if (semaphore0 == (void *)-1){
        perror("sem_open() failed");
        exit(1);
    }
    semId = shmget(IPC_PRIVATE, SEGMENT_SIZE, IPC_CREAT | IPC_EXCL | S_IRUSR | S_IWUSR);
    if (semId == -1){
        printf("UNABLE TO CREATE SHARED MEMORY\n");
        exit(-1);
    }
    numCharsInitial = (int *) shmat(semId, NULL, 0);
    for (int i = 0; i < numChildren; i++){
        if (pipe(p[i]) < 0){
            printf("FAILED TO OPEN PIPE %d\n", i);
            exit(-1);
        }
         if (fcntl(p[i][0], F_SETFL, O_NONBLOCK) < 0){
            printf("FAILED TO SET %d PIPE TO NONE BLOCKING\n", i);
            exit(-1);
        }
    }
    for (int i = 0; i < numChildren; i++){
        char temp[100], temp2[100], temp3[100];   
        forkId = fork();
        if (forkId == -1){
            printf("FAILED TO FORK PROCESS %d\n", forkId);
            exit(1);
        }
        else if (forkId == 0){
            snprintf(temp3, 100, "%d", i);
			snprintf(temp2, 100, "%d", semId);
		    snprintf(temp, 100, "%i", p[i][1]);//WRITE
            //snprintf(temp2, 100, "%i", p[i][0]);//READ
            //WILL USE SHARED MEMORY AS A SIGN WHEN TO KILL CHILDREN
		    char *args[] = {"./child", semname, temp, argv[1], temp3, temp2, NULL};
            //printf("STARTING CHILD %d IN FORK PROGRAM\n", i);
            if (execvp(args[0], args) == -1){
                perror("ERROR: ");
            }
        }
    }
	char fileName[] = "hw10.out";
	FILE *fpOut;
    fpOut = fopen(fileName, "a+");
    if (fpOut == NULL){
        printf("UNABLE TO OPEN FILE IN MAIN\n");
        exit(-1);
    }
    printf("FINISHED ALLOCATING AND FORKING AND EXECING THE CHILDREN, CHILDREN NOW RUNNING\n"); 
	int flag = 0; 
    while(flag != 1){
        for (int i = 0; i < numChildren; i++){
            //check the pipes and see which one has data
            //write data to pipes
	    memset(input,0,sizeof(input));
	    ssize_t n = read(p[i][0], input, 100);
        //CHECK IF CONTAINS FINAL WORDS
	    if (n > 0){
            char *ret;
            ret = strstr(input, "FINALWORDSINFILE");
	    	if (ret){
            *ret = '\0';
            strcat(input, ret + strlen("FINALWORDSINFILE"));
			fputs(input, fpOut);
			printf("BEGIN SHUT DOWN OF MAIN, RECEIVED FINAL INPUT FROM CHILD\n");
			//fprintf(fpOut, "%d", *numCharsInitial);
			*numCharsInitial = -1;
			flag = 1;
			break;
		}
        //printf("%s in MAIN\n", input);
		fputs(input, fpOut);
		sem_post(semaphore0);
		
	    }
        }
    } 
	printf("WAITING FOR CHILDREN TO FINISH\n");
	while ((waitId = wait(&status)) > 0){
		//FREE THE SEMAPHORE FOR ANY CHILDREN THAT ARE WAITING ON IT 
		sem_getvalue(semaphore0, &value);
		if (value != 1){
			sem_post(semaphore0);	
		}
		usleep(5000);	
	}
	printf("PARENT DESTROYING SEMAPHORE AND SHARED MEMORY\nFINISHED\n");
	fclose(fpOut);
	for (int i = 0; i <numChildren; i++){
		close(p[i][0]);
	}
	shmdt(numCharsInitial);
	shmctl(semId, IPC_RMID, 0);
	sem_destroy(semaphore0);
    return 0;
}
