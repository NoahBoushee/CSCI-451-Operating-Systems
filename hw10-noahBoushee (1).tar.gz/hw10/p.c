/*
NOAH BOUSHEE
Child program of homework 10, this child is duplicated 9 times
These children are syncrhonized with a semaphore, when it is their turn,
they generate a number between 1 and 10 and read that many characters from a file.
That child then sends those characters to main through pipe and adds number of read
characters to shared memory.

*/

#include <semaphore.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <fcntl.h>

#define upper 10
#define lower 1

int main(int argc, char *argv[]){
    //argv[0] == progName, 
	//printf("%s %s %s %s %s %s\n", argv[0], argv[1], argv[2], argv[3], argv[4], argv[5]);
    sem_t *semaphore0;
    int oflag = O_CREAT, p[2], p1[2];
    mode_t mode = 0644;
    char input[150], tempWord[25];
    unsigned int value = 0;
    semaphore0 = sem_open(argv[1], oflag, mode);
    if (semaphore0 == (void *)-1){
        perror("sem_open() failed");
        exit(1);
    }
    FILE *fp;
    fp = fopen(argv[3], "r");
    if (fp == NULL){
        printf("UNABLE TO OPEN FILE IN PROGRAM %s\n", argv[4]);
        exit(1);
    }
    //GETS THE PIPE WRITE OPEN
	int fd = atoi(argv[2]), randomNum;
	int* memShare;
    srand(time(0));
	//printf("BEGINING CHILD %s\n", argv[4]);
    while (1){
		sem_getvalue(semaphore0, &value);
		while (value != 1){
			usleep(5000);
			sem_getvalue(semaphore0, &value);
		}
		sem_wait(semaphore0);
        randomNum = (rand() % (upper - lower + 1)) + lower;
		int id = atoi(argv[5]);
		memShare = (int *) shmat(id , NULL, 0);
		if (*memShare == -1){
			break;
		}//EXIT ONCE PARENT TAKES DOWN SHARED MEMORY
		fseek(fp, 0, SEEK_SET);
		fseek(fp, *memShare, SEEK_CUR);
		char tempCharArray[25], tempChar;
		int i = 0, EOFLAG = 0;
		memset(tempCharArray,0,sizeof(tempCharArray));
		for (i = 0; i < randomNum;i++){
			tempChar = fgetc(fp);
			if (tempChar == EOF){
				tempCharArray[i] = '\0';
				EOFLAG = 1;
				break;
			}
			tempCharArray[i] = tempChar;
		}
		char finalWord[100];
		memset(finalWord,0,sizeof(finalWord));
		snprintf(finalWord, 100, "_p%s%s", argv[4], tempCharArray);
		//printf("READ (%s) in CHILD %s\n", finalWord, argv[4]);
        if (write(fd, finalWord, strlen(finalWord)) == -1){
			printf("ERROR WRITING TO PIPE %s\n", argv[4]);
		}
		*memShare = (*memShare) + i;
		if (i < randomNum-1 || EOFLAG == 1){//READ LESS THAN DESIRED THEREFOR END OF FILE	
			char finalVal[50];
			snprintf(finalVal, 50, "%d FINALWORDSINFILE", *memShare);
			write(fd, finalVal, sizeof(finalVal));
			//sem_trywait(semaphore0);
			break;
		}
		//sem_trywait(semaphore0);
		usleep(5000);
    }
    close(fd);
	shmdt(memShare);
    //printf("FINISHED CHILD %s AND CLOSING WRITE END OF PIPE %s\n", argv[4], argv[4]);
    return 0;
}
